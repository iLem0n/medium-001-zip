package de.ilem0n.sessions.statechecks;

import de.ilem0n.KubernetesClient;

public class SessionStateCheckNamespaceExists implements SessionStateCheck {

    private final KubernetesClient k8s;

    public SessionStateCheckNamespaceExists(KubernetesClient k8s) {
        this.k8s = k8s;
    }

    @Override
    public boolean doCheck(String sessionId) {
        return k8s.namespaces().withName(sessionId) != null;
    }
}
