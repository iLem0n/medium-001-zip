package de.ilem0n.sessions.statechecks;

import de.ilem0n.FlinkApiBuilder;
import de.ilem0n.KubernetesClient;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.ArrayList;

@ApplicationScoped
public class SessionHealthCheck {

    private final ArrayList<SessionStateCheck> stateChecks = new ArrayList<>();

    @Inject
    SessionHealthCheck(KubernetesClient k8s, FlinkApiBuilder flinkApiBuilder) {
        stateChecks.add(new SessionStateCheckNamespaceExists(k8s));
        stateChecks.add(new SessionStateCheckFlinkApiReachable(flinkApiBuilder));
    }

    public boolean isHealthy(String sessionId) {
        for (SessionStateCheck check : stateChecks) {
            if (!check.doCheck(sessionId)) {
                return false;
            }
        }
        return true;
    }
}
