package de.ilem0n.sessions.bootstrap;

import de.ilem0n.FlinkApiBuilder;
import de.ilem0n.JobManagerEndpointProvider;
import de.ilem0n.KubernetesClient;
import de.ilem0n.LabelProvider;
import de.ilem0n.sessions.bootstrap.strategies.*;
import io.fabric8.kubernetes.api.model.ConfigMap;
import io.quarkus.logging.Log;
import io.quarkus.runtime.Startup;
import io.vertx.core.eventbus.EventBus;
import org.eclipse.microprofile.config.inject.ConfigProperty;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.ArrayList;

@ApplicationScoped
@Startup
public class SessionBootstrapper {

    @Inject EventBus eventBus;
    @Inject KubernetesClient k8s;
    @Inject FlinkApiBuilder flinkApiBuilder;
    @Inject JobManagerEndpointProvider jobManagerEndpointProvider;
    @Inject LabelProvider sessionLabelProvider;

    @ConfigProperty(name = "session.bootstrap.override-namespace")
    boolean overrideNamespace;

    @ConfigProperty(name = "operations.namespace")
    String operationsNamespace;

    @ConfigProperty(name = "operations.flink.config-map")
    String flinkConfigMapName;

    @ConfigProperty(name = "operations.flink.templates-config-map")
    String flinkTemplatesConfigMapName;

    private final ArrayList<SessionBootstrapStrategy> preBootstrapStrategies = new ArrayList<>();
    private final ArrayList<SessionBootstrapStrategy> bootstrapStrategies = new ArrayList<>();
    private final ArrayList<SessionBootstrapStrategy> rollbackStrategies = new ArrayList<>();


    private final ArrayList<SessionBootstrapStrategy> postBootstrapStrategies = new ArrayList<>();

    private void prepareStrategies(String sessionId) {
        preBootstrapStrategies.add(new BootstrapStrategyCreateNamespace(k8s, sessionId, overrideNamespace));

        rollbackStrategies.add(new BootstrapStrategyRollback(k8s, sessionId));

        bootstrapStrategies.add(new BootstrapStrategyPreparePermissions(k8s, sessionId));
        bootstrapStrategies.add(new BootstrapStrategyCopyResource<>(k8s, ConfigMap.class, flinkConfigMapName, operationsNamespace, sessionId));
        bootstrapStrategies.add(new BootstrapStrategyCopyResource<>(k8s, ConfigMap.class, flinkTemplatesConfigMapName, operationsNamespace, sessionId));
        bootstrapStrategies.add(new BootstrapStrategyRunInitJob(k8s, sessionLabelProvider, sessionId));

        postBootstrapStrategies.add(new BootstrapStrategyVerifyHealth(k8s, flinkApiBuilder, sessionId));
    }

    public void bootstrap(String sessionId) throws SessionBootstrapException {
        prepareStrategies(sessionId);
        Log.info(String.format("[session-bootstrap] pre: %d, bootstrap: %d, post: %d, rollback: %d", preBootstrapStrategies.size(), bootstrapStrategies.size(), postBootstrapStrategies.size(), rollbackStrategies.size()));

        try {
            runPreBootstrapPhase(); // pre-bootstrap strategies will not trigger the rollback strategies if failing
            runBootstrapPhase();
        } catch (Exception exception) {
            Log.error(String.format("BootstrapError: %s", exception.getMessage()));
            throw new SessionBootstrapException(exception);
        }

        // even if error occur here the session cluster is assumed as 'running'
        runPostBootstrapPhase();
    }

    public void destroy(String sessionId) throws SessionBootstrapException {
        prepareStrategies(sessionId);
        runRollbackPhase();
    }

    /**
     * Pre-Bootstrap phase:
     * executes each pre-bootstrap strategy.
     *
     * Prepare what is needed in bootstrap phase. The difference is that an exception will not trigger a rollback.
     *
     * @throws Exception: formatted description of the inner exception
     */
    private void runPreBootstrapPhase() throws SessionBootstrapException {
        Log.info("[pre-bootstrap] start");
        for (SessionBootstrapStrategy strategie : preBootstrapStrategies) {
            Log.info(String.format("[pre-bootstrap] perform '%s'", strategie.getClass().getSimpleName()));
            try {
                strategie.run();
            } catch (Exception exception) {
                String errorMessage = formatStrategyError("pre-bootstrap", strategie, exception);
                throw new SessionBootstrapException(errorMessage);
            }
        }
        Log.info("[pre-bootstrap] done");
    }

    /**
     * Bootstrap phase:
     * executes each bootstrap strategy.
     * If an inner exception is thrown. The rollback phase will be triggered
     *
     * The main tasks for deploying a session cluster
     *
     * @throws Exception: formatted description of the inner exception
     */
    private void runBootstrapPhase() throws SessionBootstrapException {
        Log.info("[bootstrap] start");
        for (SessionBootstrapStrategy strategy : bootstrapStrategies) {
            try {
                Log.info(String.format("[bootstrap] perform '%s'", strategy.getClass().getSimpleName()));
                strategy.run();
            } catch (Exception exception) {
                runRollbackPhase();
                throw new SessionBootstrapException(formatStrategyError("bootstrap", strategy, exception));
            }
        }
        Log.info("[bootstrap] done");
    }

    /**
     * Rollback phase:
     * executes each rollback strategy
     *
     * Here you should revert all you changes made in the previous phases
     *
     * @throws Exception: formatted description of the inner exception
     */
    private void runRollbackPhase() throws SessionBootstrapException {
        Log.info("[rollback] start");
        for (SessionBootstrapStrategy strategy : rollbackStrategies) {
            try {
                Log.info(String.format("[rollback] perform '%s'", strategy.getClass().getSimpleName()));
                strategy.run();
            } catch (Exception exception) {
                throw new SessionBootstrapException(formatStrategyError("rollback", strategy, exception));
            }
        }
        Log.info("[rollback] done");
    }

    /**
     * Post-Bootstrap phase:
     * executes each post-bootstrap strategy
     *
     * Here you should do verification and cleanup
     *
     * @throws Exception: formatted description of the inner exception
     */
    private void runPostBootstrapPhase() throws SessionBootstrapException {
        Log.info("[post-bootstrap] start");
        for (SessionBootstrapStrategy strategy : postBootstrapStrategies) {
            try {
                Log.info(String.format("[post-bootstrap] perform '%s'", strategy.getClass().getSimpleName()));
                strategy.run();
            } catch (Exception exception) {
                Log.warn("Regardless of the errors the cluster '%s' is still assumed as RUNNING since these errors occurred in the post boostrap phase. Anyway you should investigate on this.");
                throw new SessionBootstrapException(formatStrategyError("rollback", strategy, exception));
            }
        }
        Log.info("[post-bootstrap] done");
    }



    private String formatStrategyError(String phase, SessionBootstrapStrategy strategy, Exception exception) {
        return String.format("[%s] error in '%s': %s, %s, %s", phase, strategy.getClass().getSimpleName(), exception, exception.getMessage(), exception.getCause());
    }
}
