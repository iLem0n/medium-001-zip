package de.ilem0n.sessions.bootstrap;

public class SessionBootstrapException extends Exception {
    public SessionBootstrapException(String message) {
        super(message);
    }

    public SessionBootstrapException(Throwable cause) {
        super(cause.getMessage());
        initCause(cause);
    }
}
