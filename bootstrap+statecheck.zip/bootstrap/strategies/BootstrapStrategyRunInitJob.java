package de.ilem0n.sessions.bootstrap.strategies;

import de.ilem0n.KubernetesClient;
import de.ilem0n.LabelProvider;
import de.ilem0n.sessions.bootstrap.SessionBootstrapException;
import io.fabric8.kubernetes.api.model.Pod;
import io.fabric8.kubernetes.api.model.batch.v1.Job;
import io.fabric8.kubernetes.client.utils.Serialization;
import io.quarkus.logging.Log;
import org.eclipse.microprofile.config.ConfigProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

public class BootstrapStrategyRunInitJob extends SessionBootstrapStrategy {
    private static final Logger log = LoggerFactory.getLogger(BootstrapStrategyRunInitJob.class);

    private final String sessionId;
    private final LabelProvider labelProvider;

    private final int k8sDefaultTimeoutValue = ConfigProvider.getConfig().getValue(
        "operations.k8s.default-timeout.value",
        int.class
    );

    private final String k8sDefaultTimeoutUnit = ConfigProvider.getConfig().getValue(
        "operations.k8s.default-timeout.unit",
        String.class
    );

    private final String flinkBaseImage = ConfigProvider
        .getConfig()
        .getValue("flink.base-image", String.class);

    private final String serviceAccountName = ConfigProvider
        .getConfig()
        .getValue("operations.service-account.name", String.class);

    private final String flinkConfigMapName = ConfigProvider
        .getConfig()
        .getValue("operations.flink.config-map", String.class);

    private final String flinkTemplatesConfigMapName = ConfigProvider
        .getConfig()
        .getValue("operations.flink.templates-config-map", String.class);

    public BootstrapStrategyRunInitJob(KubernetesClient k8s, LabelProvider sessionLabelProvider, String sessionId) {
        super(k8s);
        this.sessionId = sessionId;
        this.labelProvider = sessionLabelProvider;
    }

    @Override
    public void run() throws SessionBootstrapException {
        Log.info("[BootstrapStrategyRunInitJob] start");

        try {
            InputStream initJobYamlStream = Objects.requireNonNull(getClass().getClassLoader().getResource("init-job.yaml")).openStream();
            Job initJob = Serialization.unmarshal(initJobYamlStream);
            log.info(String.format("JobResource.yaml: %s", initJob));

            initJob.getMetadata().setNamespace(sessionId);
            initJob.getSpec().getTemplate().getMetadata().setName(String.format("init-%s", sessionId));
            initJob.getSpec().getTemplate().getMetadata().setNamespace(sessionId);
            initJob.getSpec().getTemplate().getSpec().getContainers().get(0).setImage(flinkBaseImage);
            initJob.getSpec().getTemplate().getSpec().setServiceAccountName(serviceAccountName);
            initJob.getSpec().getTemplate().getSpec().getVolumes().get(0).getConfigMap().setName(flinkConfigMapName);
            initJob.getSpec().getTemplate().getSpec().getVolumes().get(1).getConfigMap().setName(flinkTemplatesConfigMapName);

            String[] extraCommands = new String[] {
                String.format("-Dkubernetes.jobmanager.labels=%s", labelProvider.sessionLabelsAsString(sessionId)),
                String.format("-Dkubernetes.cluster-id=%s", sessionId),
                String.format("-Dkubernetes.service-account=%s", serviceAccountName),
                String.format("-Dkubernetes.namespace=%s", sessionId),
                String.format("-Dkubernetes.container.image=%s", flinkBaseImage)
            };

            for (String extraCommand : extraCommands) {
                initJob.getSpec().getTemplate().getSpec().getContainers().get(0).getCommand().add(extraCommand);
            }

            k8s.batch().v1().jobs().inNamespace(initJob.getMetadata().getNamespace()).create(initJob);
            k8s.batch().v1().jobs().inNamespace(initJob.getMetadata().getNamespace())
                .withName(initJob.getMetadata().getName())
                .waitUntilCondition(
                    j -> j.getStatus() != null && j.getStatus().getSucceeded() != null && j.getStatus().getSucceeded() == 1,
                    5,
                    TimeUnit.MINUTES
                );


            List<Pod> jobManagerPodList = k8s.pods().inNamespace(sessionId).withLabels(labelProvider.jobManagerPodLabels()).list().getItems();
            if (jobManagerPodList.size() != 1) {
                throw new SessionBootstrapException("JobManger count after Init-Job != 1");
            }

            String jobManagerPodName = jobManagerPodList.get(0).getMetadata().getName();
            k8s.pods().inNamespace(sessionId).withName(jobManagerPodName).waitUntilReady(10, TimeUnit.MINUTES);

        } catch (IOException exception) {
            Log.error(String.format("IOException: %s", exception));
            throw new SessionBootstrapException(exception);
        }
        Log.info("[BootstrapStrategyRunInitJob] end");

    }
}
