package de.ilem0n.sessions.bootstrap.strategies;

import de.ilem0n.KubernetesClient;
import de.ilem0n.sessions.bootstrap.SessionBootstrapException;

public abstract class SessionBootstrapStrategy {

    final KubernetesClient k8s;

    SessionBootstrapStrategy(KubernetesClient k8s) {
        this.k8s = k8s;
    }

    public abstract void run() throws SessionBootstrapException;
}

