package de.ilem0n.sessions.bootstrap.strategies;

import com.nextbreakpoint.flinkclient.api.ApiException;
import com.nextbreakpoint.flinkclient.api.FlinkApi;
import de.ilem0n.FlinkApiBuilder;
import de.ilem0n.FlinkApiBuilderException;
import de.ilem0n.KubernetesClient;
import de.ilem0n.sessions.bootstrap.SessionBootstrapException;
import io.quarkus.logging.Log;

public class BootstrapStrategyVerifyHealth extends SessionBootstrapStrategy {

    private final String sessionId;
    private final FlinkApiBuilder flinkApiBuilder;


    public BootstrapStrategyVerifyHealth(KubernetesClient k8s, FlinkApiBuilder flinkApiBuilder, String sessionId) {
        super(k8s);
        this.sessionId = sessionId;
        this.flinkApiBuilder = flinkApiBuilder;
    }

    @Override
    public void run() throws SessionBootstrapException {
        Log.info("[BootstrapStrategyVerifyHealth] start");

        while (true) {
            try {
                FlinkApi flinkApi = flinkApiBuilder.withTimeout(3000).build(sessionId);
                flinkApi.getJobs();
                break;
            } catch (FlinkApiBuilderException flinkApiBuilderException) {
                Log.error("FlinkApiBuilderException: %s", flinkApiBuilderException);
                break;
            } catch (ApiException apiException) {
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException interruptedException) {
                    Log.error("InterruptedException: %s", interruptedException);
                    break;
                }
            }
        }

        Log.info("[BootstrapStrategyVerifyHealth] end");
    }
}
