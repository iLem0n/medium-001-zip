package de.ilem0n.sessions.bootstrap.strategies;

import de.ilem0n.KubernetesClient;
import de.ilem0n.sessions.bootstrap.SessionBootstrapException;
import io.fabric8.kubernetes.api.model.Namespace;
import io.fabric8.kubernetes.api.model.NamespaceBuilder;
import io.quarkus.logging.Log;
import org.eclipse.microprofile.config.ConfigProvider;

import java.util.Objects;
import java.util.concurrent.TimeUnit;

public class BootstrapStrategyCreateNamespace extends SessionBootstrapStrategy {

    private final int k8sDefaultTimeoutValue = ConfigProvider.getConfig().getValue(
        "operations.k8s.default-timeout.value",
        int.class
    );
    private final TimeUnit k8sDefaultTimeoutUnit = TimeUnit.valueOf(
        ConfigProvider.getConfig().getValue(
            "operations.k8s.default-timeout.unit",
            String.class
        )
    );

    private final boolean overrideNamespace;
    private final String namespaceName;

    public BootstrapStrategyCreateNamespace(KubernetesClient k8s, String namespaceName) {
        this(k8s, namespaceName, false);
    }

    public BootstrapStrategyCreateNamespace(KubernetesClient k8s, String namespaceName, boolean override) {
        super(k8s);
        this.namespaceName = namespaceName;
        this.overrideNamespace = override;
    }

    @Override
    public void run() throws SessionBootstrapException {
        Log.info("[BootstrapStrategyCreateNamespace] start");

        // build namespace entity
        removeExistingIfDesired();

        // create namespace on k8s
        k8s.namespaces().create(buildNamespace());
        k8s.namespaces()
            .withName(namespaceName)
            .waitUntilCondition(
                Objects::nonNull,
                k8sDefaultTimeoutValue,
                k8sDefaultTimeoutUnit
            );
        Log.info("[BootstrapStrategyCreateNamespace] end");
    }

    private Namespace buildNamespace() {
        return new NamespaceBuilder()
            .withNewMetadata()
            .withName(namespaceName)
            .endMetadata()
            .build();
    }

    private void removeExistingIfDesired() throws SessionBootstrapException {
        Namespace existingNamespace = k8s.namespaces().withName(namespaceName).get();
        if (existingNamespace != null) {
            if (overrideNamespace) {
                Log.warn(String.format("found already existing namespace '%s'. Will override it since 'session.bootstrap.override-namespace'-config is 'true'.", namespaceName));
                deleteNamespace();
            } else {
                throw new SessionBootstrapException(String.format("Namespace '%s' already exists and should not be overridden.", namespaceName));
            }
        }
    }

    private void deleteNamespace() {
        k8s.namespaces().withName(namespaceName).delete();
        k8s.namespaces()
            .withName(namespaceName)
            .waitUntilCondition(
                Objects::isNull,
                10,
                TimeUnit.MINUTES
            );
    }
}
