package de.ilem0n.sessions.statechecks;

import com.nextbreakpoint.flinkclient.api.ApiException;
import de.ilem0n.FlinkApiBuilder;
import de.ilem0n.FlinkApiBuilderException;
import io.quarkus.logging.Log;

public class SessionStateCheckFlinkApiReachable implements SessionStateCheck {
    private final FlinkApiBuilder flinkApiBuilder;

    public SessionStateCheckFlinkApiReachable(FlinkApiBuilder flinkApiBuilder) {
        this.flinkApiBuilder = flinkApiBuilder;
    }

    @Override
    public boolean doCheck(String sessionId) {
        try {
            flinkApiBuilder.build(sessionId).getJobs();
            return true;
        } catch (FlinkApiBuilderException | ApiException exception) {
            Log.warn(String.format("Exception in state check [%s]: %s", this, exception));
            return false;
        }
    }
}
