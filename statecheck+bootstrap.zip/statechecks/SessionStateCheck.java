package de.ilem0n.sessions.statechecks;

public interface SessionStateCheck {
    boolean doCheck(String sessionId);
}
