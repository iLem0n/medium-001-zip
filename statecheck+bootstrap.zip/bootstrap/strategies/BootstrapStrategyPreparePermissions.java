package de.ilem0n.sessions.bootstrap.strategies;

import de.ilem0n.KubernetesClient;
import de.ilem0n.sessions.bootstrap.SessionBootstrapException;
import io.fabric8.kubernetes.api.model.ServiceAccount;
import io.fabric8.kubernetes.api.model.ServiceAccountBuilder;
import io.fabric8.kubernetes.api.model.rbac.ClusterRoleBinding;
import io.fabric8.kubernetes.api.model.rbac.Subject;
import io.fabric8.kubernetes.api.model.rbac.SubjectBuilder;
import io.quarkus.logging.Log;
import org.eclipse.microprofile.config.ConfigProvider;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

public class BootstrapStrategyPreparePermissions extends SessionBootstrapStrategy {
    private final int k8sDefaultTimeoutValue = ConfigProvider.getConfig().getValue(
        "operations.k8s.default-timeout.value",
        int.class
    );

    private final String k8sDefaultTimeoutUnit = ConfigProvider.getConfig().getValue(
        "operations.k8s.default-timeout.unit",
        String.class
    );

    private final String operationsServiceAccountName = ConfigProvider.getConfig().getValue(
        "operations.service-account.name",
        String.class
    );

    private final String operationsClusterRoleBindingName = ConfigProvider.getConfig().getValue(
        "operations.clusterrole-binding.name",
        String.class
    );

    private final String namespaceName;

    public BootstrapStrategyPreparePermissions(KubernetesClient k8s, String namespaceName) {
        super(k8s);
        this.namespaceName = namespaceName;
    }

    @Override
    public void run() throws SessionBootstrapException {
        Log.info("[BootstrapStrategyPreparePermissions] start");

        ClusterRoleBinding operationsClusterRoleBinding = getSourceClusterRoleBinding();
        upsertServiceAccount();
        waitUntilCreated();
        updateClusterRoleBinding(operationsClusterRoleBinding);
        Log.info("[BootstrapStrategyPreparePermissions] end");

    }

    public ServiceAccount getServiceAccount(String namespace) {
        return k8s.serviceAccounts()
            .inNamespace(namespace)
            .withName(operationsServiceAccountName)
            .get();
    }

    private ClusterRoleBinding getSourceClusterRoleBinding() throws SessionBootstrapException {
        ClusterRoleBinding operationsClusterRoleBinding = k8s.rbac().clusterRoleBindings().withName(operationsClusterRoleBindingName).get();
        if (operationsClusterRoleBinding == null) {
            throw new SessionBootstrapException(String.format("Unable to find ClusterRoleBinding: %s", operationsClusterRoleBindingName));
        }
        return operationsClusterRoleBinding;
    }

    private void upsertServiceAccount() {
        ServiceAccount serviceAccount = getServiceAccount(namespaceName);
        if (serviceAccount == null) {
            serviceAccount = new ServiceAccountBuilder()
                .withNewMetadata()
                .withName(operationsServiceAccountName)
                .withNamespace(namespaceName)
                .endMetadata()
                .build();
            k8s.serviceAccounts().inNamespace(namespaceName).create(serviceAccount);
            k8s.serviceAccounts()
                .inNamespace(namespaceName)
                .withName(operationsServiceAccountName)
                .waitUntilCondition(
                    Objects::nonNull,
                    k8sDefaultTimeoutValue,
                    TimeUnit.valueOf(k8sDefaultTimeoutUnit)
                );
        }
    }

    private void waitUntilCreated() {
        k8s.serviceAccounts()
            .inNamespace(namespaceName)
            .withName(operationsServiceAccountName)
            .waitUntilCondition(
                Objects::nonNull,
                k8sDefaultTimeoutValue,
                TimeUnit.valueOf(k8sDefaultTimeoutUnit)
            );
    }

    private void updateClusterRoleBinding(ClusterRoleBinding crb) {
        List<Subject> subjects = crb.getSubjects();
        if (subjects.stream().noneMatch(subject -> subject.getNamespace().equals(namespaceName))) {
            ArrayList<Subject> newSubjects = new ArrayList<>(subjects);
            newSubjects.add(new SubjectBuilder()
                .withName(operationsServiceAccountName)
                .withKind("ServiceAccount")
                .withNamespace(namespaceName)
                .build());
            crb.setSubjects(newSubjects);
            k8s.rbac().clusterRoleBindings().createOrReplace(crb);
        }
    }
}
