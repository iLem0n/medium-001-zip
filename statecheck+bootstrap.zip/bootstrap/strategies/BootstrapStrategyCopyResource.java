package de.ilem0n.sessions.bootstrap.strategies;

import de.ilem0n.KubernetesClient;
import de.ilem0n.sessions.bootstrap.SessionBootstrapException;
import io.fabric8.kubernetes.api.model.HasMetadata;
import io.fabric8.kubernetes.client.dsl.Resource;
import io.quarkus.logging.Log;
import org.eclipse.microprofile.config.ConfigProvider;

import java.util.Objects;
import java.util.concurrent.TimeUnit;

public class BootstrapStrategyCopyResource<T extends HasMetadata> extends SessionBootstrapStrategy {
    private final int k8sDefaultTimeoutValue = ConfigProvider.getConfig().getValue(
            "operations.k8s.default-timeout.value",
            int.class
        );
    private final String k8sDefaultTimeoutUnit = ConfigProvider.getConfig().getValue(
            "operations.k8s.default-timeout.unit",
            String.class
        );

    private final Class<T> resourceType;
    private final String resourceName;
    private final String resourceNamespace;
    private final String targetNamespace;

    public BootstrapStrategyCopyResource(KubernetesClient k8s, Class<T> resourceType, String resourceName, String resourceNamespace, String targetNamespace) {
        super(k8s);
        this.resourceType = resourceType;
        this.resourceName = resourceName;
        this.resourceNamespace = resourceNamespace;
        this.targetNamespace = targetNamespace;
    }

    @Override
    public void run() throws SessionBootstrapException {
        Log.info("[BootstrapStrategyCopyResource] start");

        Resource<T> resourceRef = k8s.resources(resourceType)
            .inNamespace(resourceNamespace)
            .withName(resourceName);

        HasMetadata resource = resourceRef.get();

        if (resource == null) {
            throw new SessionBootstrapException(String.format(
                "SourceResource == 'null': expecting '%s' named '%s' in '%s'-namespace",
                resourceType.getSimpleName(),
                resourceName,
                resourceNamespace
            ));
        }

        resource.getMetadata().setNamespace(targetNamespace);
        k8s.resource(resource).createOrReplace();
        k8s.resource(resource).inNamespace(targetNamespace)
            .waitUntilCondition(
                Objects::nonNull,
                k8sDefaultTimeoutValue,
                TimeUnit.valueOf(k8sDefaultTimeoutUnit)
            );
        Log.info("[BootstrapStrategyCopyResource] end");

    }
}
