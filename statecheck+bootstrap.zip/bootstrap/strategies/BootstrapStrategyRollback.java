package de.ilem0n.sessions.bootstrap.strategies;

import de.ilem0n.KubernetesClient;
import de.ilem0n.sessions.bootstrap.SessionBootstrapException;
import io.quarkus.logging.Log;
import org.eclipse.microprofile.config.ConfigProvider;

import java.util.Objects;
import java.util.concurrent.TimeUnit;

public class BootstrapStrategyRollback extends SessionBootstrapStrategy {

    private final int k8sDefaultTimeoutValue = ConfigProvider.getConfig().getValue(
        "operations.k8s.default-timeout.value",
        int.class
    );
    private final String k8sDefaultTimeoutUnit = ConfigProvider.getConfig().getValue(
        "operations.k8s.default-timeout.unit",
        String.class
    );

    private final String sessionId;

    public BootstrapStrategyRollback(KubernetesClient k8s, String sessionId) {
        super(k8s);
        this.sessionId = sessionId;
    }

    @Override
    public void run() throws SessionBootstrapException {
        Log.info("[BootstrapStrategyRollback] start");
        k8s.namespaces().withName(sessionId).delete();
        k8s.namespaces()
            .withName(sessionId)
            .waitUntilCondition(
                Objects::isNull,
                k8sDefaultTimeoutValue,
                TimeUnit.valueOf(k8sDefaultTimeoutUnit)
            );
        Log.info("[BootstrapStrategyRollback] end");
    }
}
